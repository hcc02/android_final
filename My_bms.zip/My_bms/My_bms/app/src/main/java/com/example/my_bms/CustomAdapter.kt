package com.example.my_bms

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import android.database.sqlite.SQLiteDatabase

class CustomAdapter(
    context: Context,
    private val items: ArrayList<String>,
    private val dbrw: SQLiteDatabase
) : ArrayAdapter<String>(context, 0, items) {

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val inflater = context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val rowView = inflater.inflate(R.layout.list_item, parent, false)

        val tvItem = rowView.findViewById<TextView>(R.id.tv_item)
        tvItem.text = items[position]

        val btnDelete = rowView.findViewById<Button>(R.id.btn_delete)
        btnDelete.setOnClickListener {
            val book = items[position].split("\t\t\t\t")[0].split(":")[1]
            dbrw.execSQL("DELETE FROM myTable WHERE book = ?", arrayOf(book))
            items.removeAt(position)
            notifyDataSetChanged()
            Toast.makeText(context, "刪除: $book", Toast.LENGTH_SHORT).show()
        }

        return rowView
    }
}
