package com.example.my_bms

import android.database.sqlite.SQLiteDatabase
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    private var items: ArrayList<String> = ArrayList()
    private lateinit var adapter: CustomAdapter
    private lateinit var database: SQLiteDatabase
    private lateinit var tvTotalAmount: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        database = MyDBHelper(this).writableDatabase
        adapter = CustomAdapter(this, items, database)
        findViewById<ListView>(R.id.listView).adapter = adapter
        tvTotalAmount = findViewById(R.id.tv_total_amount) // 新增的 TextView
        setListener()
    }

    private fun enableEdgeToEdge() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            window.setDecorFitsSystemWindows(false)
        } else {
            ViewCompat.setOnApplyWindowInsetsListener(window.decorView) { view, insets ->
                val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
                view.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
                insets
            }
        }
    }

    private fun setListener() {
        val edBook = findViewById<EditText>(R.id.ed_book)
        val edPrice = findViewById<EditText>(R.id.ed_price)

        findViewById<Button>(R.id.btn_insert).setOnClickListener {
            if (edBook.length() < 1 || edPrice.length() < 1) {
                showToast("欄位請勿空白")
            } else {
                try {
                    database.execSQL(
                        "INSERT INTO myTable(book, price) VALUES(?,?)",
                        arrayOf(edBook.text.toString(), edPrice.text.toString())
                    )
                    showToast("新增:${edBook.text}, 價格:${edPrice.text}")
                    cleanEditText()
                } catch (e: Exception) {
                    showToast("新增失敗: $e")
                }
            }
        }

        findViewById<Button>(R.id.btn_update).setOnClickListener {
            if (edBook.length() < 1 || edPrice.length() < 1) {
                showToast("欄位請勿空白")
            } else {
                try {
                    database.execSQL(
                        "UPDATE myTable SET price = ? WHERE book LIKE ?",
                        arrayOf(edPrice.text.toString(), edBook.text.toString())
                    )
                    showToast("更新:${edBook.text}, 價格:${edPrice.text}")
                    cleanEditText()
                } catch (e: Exception) {
                    showToast("更新失敗: $e")
                }
            }
        }

        findViewById<Button>(R.id.btn_delete).setOnClickListener {
            if (edBook.length() < 1) {
                showToast("餐點請勿空白")
            } else {
                try {
                    database.execSQL(
                        "DELETE FROM myTable WHERE book LIKE ?",
                        arrayOf(edBook.text.toString())
                    )
                    showToast("刪除:${edBook.text}")
                    cleanEditText()
                } catch (e: Exception) {
                    showToast("刪除失敗: $e")
                }
            }
        }

        findViewById<Button>(R.id.btn_query).setOnClickListener {
            val queryString = if (edBook.length() < 1)
                "SELECT * FROM myTable"
            else
                "SELECT * FROM myTable WHERE book LIKE ?"
            val args = if (edBook.length() < 1) null else arrayOf(edBook.text.toString())
            val cursor = database.rawQuery(queryString, args)
            cursor.moveToFirst()
            items.clear()
            var total = 0
            showToast("共有${cursor.count}筆資料")
            for (i in 0 until cursor.count) {
                items.add("餐點:${cursor.getString(0)}\t\t\t\t價格:${cursor.getString(1)}")
                total += cursor.getString(1).toInt()
                cursor.moveToNext()
            }
            adapter.notifyDataSetChanged()
            cursor.close()
            tvTotalAmount.text = "總金額: $$total"
        }

        findViewById<Button>(R.id.btn_checkout).setOnClickListener {
            showToast("訂單已送出")
        }
    }

    override fun onDestroy() {
        database.close()
        super.onDestroy()
    }

    private fun cleanEditText() {
        findViewById<EditText>(R.id.ed_book).setText("")
        findViewById<EditText>(R.id.ed_price).setText("")
    }

    private fun showToast(text: String) {
        Toast.makeText(this, text, Toast.LENGTH_LONG).show()
    }
}
