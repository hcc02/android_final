package com.example.myapplication

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class Menu: AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.menu)

        val menuListView = findViewById<ListView>(R.id.menuListView)

        val items = listOf(
            MenuItem("咖啡", 50),
            MenuItem("三明治", 80),
            MenuItem("鬆餅", 70),
            MenuItem("紅茶", 40),
            MenuItem("歐姆蛋", 60)
        )

        val adapter = MenuAdapter(this, items)
        menuListView.adapter = adapter

        menuListView.onItemClickListener = AdapterView.OnItemClickListener { parent, view, position, id ->
            val selectedItem = items[position]
            val intent = Intent(this, customize::class.java)
            intent.putExtra("name", selectedItem.name)
            intent.putExtra("price", selectedItem.price)
            startActivity(intent)
        }
    }

    private class MenuAdapter(context: Context, private val items: List<MenuItem>) :
        ArrayAdapter<MenuItem>(context, R.layout.menu_list, items) {

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val view = convertView ?: LayoutInflater.from(context).inflate(R.layout.menu_list, parent, false)
            val item = items[position]
            val itemName = view.findViewById<TextView>(R.id.itemName)
            val itemPrice = view.findViewById<TextView>(R.id.itemPrice)

            itemName.text = item.name
            itemPrice.text = "${item.price}元"

            return view
        }
    }
}
