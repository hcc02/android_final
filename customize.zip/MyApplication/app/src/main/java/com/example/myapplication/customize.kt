package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class customize : AppCompatActivity() {
    private lateinit var dbHelper: CartDatabaseHelper
    private var quantity = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.customize)

        dbHelper = CartDatabaseHelper(this)

        val itemName = findViewById<TextView>(R.id.itemName)
        val itemDescription = findViewById<TextView>(R.id.itemDescription)
        val itemPrice = findViewById<TextView>(R.id.itemPrice)
        val breadOptions = findViewById<Spinner>(R.id.breadOptions)
        val addCheese = findViewById<CheckBox>(R.id.addCheese)
        val addEgg = findViewById<CheckBox>(R.id.addEgg)
        val noMayo = findViewById<CheckBox>(R.id.noMayo)
        val noLettuce = findViewById<CheckBox>(R.id.noLettuce)
        val note = findViewById<EditText>(R.id.note)
        val decreaseQuantity = findViewById<Button>(R.id.decreaseQuantity)
        val increaseQuantity = findViewById<Button>(R.id.increaseQuantity)
        val quantityText = findViewById<TextView>(R.id.quantity)
        val addToCart = findViewById<Button>(R.id.addToCart)

        val name = intent.getStringExtra("name")
        val price = intent.getIntExtra("price", 0)

        itemName.text = name
        itemPrice.text = "價格: $price 元"

        decreaseQuantity.setOnClickListener {
            if (quantity > 1) {
                quantity--
                quantityText.text = quantity.toString()
            }
        }

        increaseQuantity.setOnClickListener {
            quantity++
            quantityText.text = quantity.toString()
        }

        addToCart.setOnClickListener {
            val selectedBread = breadOptions.selectedItem.toString()
            val cheese = if (addCheese.isChecked) "+起司 " else ""
            val egg = if (addEgg.isChecked) "+蛋 " else ""
            val mayo = if (noMayo.isChecked) "不要沙拉醬 " else ""
            val lettuce = if (noLettuce.isChecked) "不要生菜 " else ""
            val noteText = note.text.toString()

            val customization = "$selectedBread $cheese $egg $mayo $lettuce 數量: $quantity"
            dbHelper.insertItem(customization, noteText)

            Toast.makeText(this, "已加入購物車: $customization\n備註：$noteText", Toast.LENGTH_SHORT).show()

            val intent = Intent(this, Menu::class.java)
            startActivity(intent)
        }
    }
}
